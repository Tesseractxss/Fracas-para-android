*** UPDATE: 06.03.2005 ***

Hi, this game has been released as unsupported freeware by the developers, have fun!

Nick / Tony.
